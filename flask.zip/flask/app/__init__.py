from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_script import Manager, Server
from flask_migrate import Migrate, MigrateCommand
from flask_jwt_extended import JWTManager
import jwt
from flask_cors import CORS

app = Flask(__name__)

CORS(app)
app.config.from_object('config')
db = SQLAlchemy(app)
migrate = Migrate(app, db) 
manager = Manager(app)

jwt = JWTManager(app)
app.config["JWT_SECRET_KEY"] = "NICOLEEE"
port = app.config["FLASK_PORT"]
host = app.config["FLASK_HOST"]

server = Server(host=host, port=port)
manager.add_command("runserver", server)
manager.add_command("db", MigrateCommand)

from app.models.userModel import User
from app.models.roleModel import Role
from app.models.resourceModel import Resource
from app.models.actionModel import Action
from app.models.controllerModel import Controller
from app.models.privilegeModel import Privilege

from app.controllers.userController import User
from app.controllers.roleController import Role
from app.controllers.controllerController import Controller
from app.controllers.actionController import Action
from app.controllers.resourceController import Resource
from app.controllers.privilegeController import Privilege
from app.controllers import authenticController
