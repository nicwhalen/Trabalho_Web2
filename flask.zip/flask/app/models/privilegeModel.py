from app import db

class Privilege(db.Model):
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), nullable=False, primary_key=True)
    resource_id = db.Column(db.Integer, db.ForeignKey('resource.id'), nullable=False, primary_key=True)
    allow = db.Column(db.Boolean, nullable=False)  
    
    def __repr__(self):
        return '<User %r>' % self.id

    def to_dict(self):
        return {
            "role_id": self.role_id,
            "resource_id": self.resource_id,
            "allow": self.allow
        }