from app import app, db
from app import User
from flask import request, jsonify


@app.route("/user/add", methods=["POST"])
def user_add():
    data = request.get_json()

    if "email" not in data or data["email"] is None:
        return jsonify({"error": True, "message": "Este email não existe."}), 400
    if "password" not in data or data["password"] is None:
        return jsonify({"error": True, "message": "A senha não foi informada."}), 400
    if "role_id" not in data or data["role_id"] is None:
        return jsonify({"error": True, "message": "Não existe."}), 400

    user = User(email=data["email"], password=data["password"], role_id=data["role_id"])

    try:
        db.session.add(user)
        db.session.commit()

        return jsonify({"error": False})

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "O email ou senha não foram informados"}), 400 
    
@app.route("/user/edit/<int:id>", methods=["PUT"])
def user_edit(id):
    user = User.query.get(id)

    if user == None:
        return jsonify({"message": "O usuario nao existe", "error": True})
    
    data = request.get_json()
    user.email = data["email"]
    user.password = data["password"]
    user.role_id = data["role_id"]

    try:
        db.session.commit()

        return jsonify({"error": False, "message": "Usuario atualizado com sucesso"}), 200 

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Erro ao atualizar usuario"}), 200 


@app.route("/user/view/<int:id>", methods=["GET"])
def user_view(id):
    user = User.query.get(id)

    if user == None:
        return jsonify({"message": "O usuario nao existe", "error": True})

    return jsonify({
        "data": user.to_dict(),
        "error": False
    })
    
@app.route("/user/delete/<int:id>", methods=["DELETE"])
def user_delete(id):
    user = User.query.get(id)


    if user == None:
        return jsonify({"message": "O usuario nao existe", "error": True})
    
    db.session.delete(user)

    try:
        db.session.delete(user)
        db.session.commit()

        return jsonify({"error": False, "message": "Usuario deletado com sucesso"}), 200 

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Erro ao deletar usuario"}), 200 
    
@app.route("/user/list", methods=["GET"])
def user_list():
    users = User.query.all() 
    arr = []

    for user in users: 
        arr.append(user.to_dict())

    return jsonify({"elements":arr, "error": False})