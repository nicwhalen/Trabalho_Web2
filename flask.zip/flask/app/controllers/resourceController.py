import resource
from app import app, db
from app import Resource
from flask import request, jsonify

@app.route("/resource/add", methods=["POST"])
def resource_add():
    data = request.get_json()

    if "action_id" not in data or data["action_id"] is None:
        return jsonify({"error": True, "message": "Não existe."}), 400
    if "controller_id" not in data or data["controller_id"] is None:
        return jsonify({"error": True, "message": "Não existe."}), 400
    
    resource = Resource(action_id=data["action_id"], controller_id=data["controller_id"])

    try:
        db.session.add(resource)
        db.session.commit()

        return jsonify({"error": False})

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Algum id não foi informado"}), 400 
    
@app.route("/privilege/edit/<int:id>", methods=["POST"])
def resource_edit(id):
    privilege = Resource.query.get(id)

    if resource == None:
        return jsonify({"message": "Nao existe", "error": True})
    
    data = request.get_json()
    resource.name = data["name"]

    try:
        db.session.commit()

        return jsonify({"error": False, "message": "Atualizado com sucesso"}), 200 

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Erro ao atualizar"}), 200 


@app.route("/privilege/view/<int:id>", methods=["GET"])
def resource_view(id):
    resource = Resource.query.get(id)

    if resource == None:
        return jsonify({"message": "Nao existe", "error": True})

    return jsonify({
        "data": resource.to_dict(),
        "error": False
    })
    
@app.route("/resource/delete/<int:id>", methods=["DELETE"])
def resource_delete(id):
    resource = Resource.query.get(id)


    if resource == None:
        return jsonify({"message": "Nao existe", "error": True})
    
    db.session.delete(resource)

    try:
        db.session.delete(resource)
        db.session.commit()

        return jsonify({"error": False, "message": "Deletado com sucesso"}), 200 

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Erro ao deletar"}), 200 
    
@app.route("/resource/list", methods=["GET"])
def resource_list():
    resources = Resource.query.all() 
    arr = []

    for resource in resources: 
        arr.append(resource.to_dict())

    return jsonify({"elements":arr, "error":False})