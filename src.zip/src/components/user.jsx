import React from "react";
import './login.css';
import axios from 'axios';

class Adicionar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {email: '',
                  password: '', 
                  role_id: ''};
    this.handleChangePassword = this.handleChangePassword.bind(this);
    this.handleChangeEmail = this.handleChangeEmail.bind(this);
    this.handleChangeRoleId = this.handleChangeRoleId.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChangeEmail(event) {
    this.setState({email: event.target.email});  
  }
  handleChangePassword(event){ 
    this.setState({password: event.target.password}); 
  }
  handleChangeRoleId(event){ 
    this.setState({roleid: event.target.role_id}); 
  }
  handleSubmit(event) {
    event.preventDefault();
    axios.post('http://localhost:5000/user/add', this.state)
    .then(function (response) {
      console.log(response);
    })
    .catch(function (error) {
      console.log(error);
    });

  }

  render() {
    return (
      <form onSubmit={this.handleSubmit} className="form" method='post'> <label>
          <h1>Adicionar usuario</h1>
          Email: <input type="email" value={this.state.email} onChange={this.handleChangeEmail} id="email"/> </label> 
          <br/><br/>
          <label>
          Senha: <input type="password" value={this.state.password} onChange={this.handleChangePassword} id="senha"/> 
          </label>
          <br/><br/>
          <label>
          Role Id: <input type="number" value={this.state.role_id} onChange={this.handleChangeRoleId} id="role_id"/> 
          </label>
          <br/><br/>
          <input type="submit" value="Enviar" className="button"/>
          </form>
        );
      }
    }

class Editar extends React.Component{
  constructor(props) {
    super(props);
    this.state = {id: '', 
                  email: '',
                  password: '', 
                  role_id: ''};
    this.handleChangeId = this.handleChangeId.bind(this)
    this.handleChangePassword = this.handleChangePassword.bind(this);
    this.handleChangeEmail = this.handleChangeEmail.bind(this);
    this.handleChangeRoleId = this.handleChangeRoleId.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChangeId(event){ 
    this.setState({id: event.target.id}); 
  }
  handleChangeEmail(event) {
    this.setState({email: event.target.email});  
  }
  handleChangePassword(event){ 
    this.setState({password: event.target.password}); 
  }
  handleChangeRoleId(event){ 
    this.setState({role_id: event.target.role_id}); 
  }
  handleSubmit(event) {
    event.preventDefault();
    axios.post('http://localhost:5000/user/add', this.state)
    .then(function (response) {
      console.log(response);
    })
    .catch(function (error) {
      console.log(error);
    });

  }

  render() {
    return (
      <form onSubmit={this.handleSubmit} className="form" method='post'> 
          <h1>Editar usuario</h1>
          <label>
          Id do usuario: <input type="number" value={this.state.id} onChange={this.handleChangeId} id="id"/> </label> 
          <br/><br/> 
          <label>
          Email: <input type="email" value={this.state.email} onChange={this.handleChangeEmail} id="email"/> </label> 
          <br/><br/>
          <label>
          Senha: <input type="password" value={this.state.password} onChange={this.handleChangePassword} id="senha"/> </label>
          <br/><br/>
          <label>
          Role Id: <input type="number" value={this.state.role_id} onChange={this.handleChangeRoleId} id="role_id"/> </label>
          <br/><br/>
          <input type="submit" value="Enviar" className="button"/>
          </form>
        );
      }
    }

export {Adicionar, Editar};