import React from "react";
import './login.css';

class Login extends React.Component {
    constructor(props) {
      super(props);
      this.state = {      value: '',
       password: ''    };
      this.handleChangePassword = this.handleChangePassword.bind(this);
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {
      this.setState({value: event.target.value});  
    }
    handleChangePassword(event){ 
      this.setState({password: event.target.password}); 
    }
    handleSubmit(event) {
      alert('O usuario logou com sucesso: ' + this.state.value);
      event.preventDefault();
    }
  
    render() {
      return (
        <form onSubmit={this.handleSubmit} className="form" method='post'>
            <h1>Tela de Login do Usuario</h1>
            <label>
            Email: <input type="text" value={this.state.value} onChange={this.handleChange} id="email"/> </label> 
            <label>
            Senha: <input type="password" value={this.state.password} onChange={this.handleChangePassword} id="senha"/> 
            </label>
            <br />
            <input type="submit" value="Enviar" className="button"/>
            </form>
          );
        }
      }

export default Login;  