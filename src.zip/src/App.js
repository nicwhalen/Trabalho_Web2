import './App.css';
import Login from './components/login';
import React from 'react';
import {Route, BrowserRouter as Router, Routes} from 'react-router-dom';
import {Adicionar, Editar} from './components/user';

function App() {
  return (
    <Router>
    <Routes>
      <Route path='/login' element={<Login/>} />
      <Route path='/user/add' element={<Adicionar/>} />
      <Route path='/user/edit' element={<Editar/>} />
    </Routes>
    </Router>
  );
}

export default App;